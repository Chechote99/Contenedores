# Contenedores

Aplicación Android para gestión de jornadas, viajes físicos, servicios facturables y facturación de operaciones de contenedores.

## Reglas de negocio
- Jornada: periodo completo de trabajo.
- Viaje: desplazamiento físico del camión.
- Servicio: unidad facturable.
- Puesta, Retirada y Cambio.
- Capacidades: 3, 6 y 9 m³.
- Cambio exige capacidades diferentes.
- Tarifas iniciales: 1–130 = 4 €, 131–150 = 15 €, 151–180 = 20 €.
- Periodo de facturación: día 16 al día 15.
- El número de servicio se asigna al finalizar, evitando huecos por cancelaciones.
- Km reales = odómetro final - inicial.
- Km del Viaje son independientes y pueden proceder de Maps/Routes.

## Requisitos de compilación
- JDK 17
- Gradle 9.4.1
- Android Gradle Plugin 9.2.0
- Android SDK 37

## Claves Google
Crear `local.properties` a partir de:

```properties
MAPS_API_KEY=
PLACES_API_KEY=
ROUTES_API_KEY=
```

No subir `local.properties` al repositorio.

## Estado
La estructura y el código base están consolidados. La compilación real requiere un entorno Android con SDK 37/JDK 17 y acceso a los repositorios Maven; esta sesión no dispone de un Gradle instalado ni de un SDK Android local para ejecutar `assembleDebug`.
