package com.contenedores.app

import com.contenedores.app.data.entity.TramoTarifaEntity
import com.contenedores.app.data.entity.TipoServicio
import com.contenedores.app.domain.billing.FacturacionCalculator
import com.contenedores.app.domain.billing.PeriodoFacturacionCalculator
import com.contenedores.app.domain.servicio.ServicioValidator
import org.junit.Assert.*
import org.junit.Test
import java.math.BigDecimal
import java.time.LocalDate

class DomainTests {
    private val calc = FacturacionCalculator(listOf(
        TramoTarifaEntity(desdeServicio=1,hastaServicio=130,importePorServicio=BigDecimal("4.00")),
        TramoTarifaEntity(desdeServicio=131,hastaServicio=150,importePorServicio=BigDecimal("15.00")),
        TramoTarifaEntity(desdeServicio=151,hastaServicio=180,importePorServicio=BigDecimal("20.00"))
    ))
    @Test fun limites() {
        assertEquals(BigDecimal("0"),calc.calcular(0).total)
        assertEquals(BigDecimal("520.00"),calc.calcular(130).total)
        assertEquals(BigDecimal("535.00"),calc.calcular(131).total)
        assertEquals(BigDecimal("820.00"),calc.calcular(150).total)
        assertEquals(BigDecimal("840.00"),calc.calcular(151).total)
        assertEquals(BigDecimal("1020.00"),calc.calcular(160).total)
        assertEquals(BigDecimal("1280.00"),calc.calcular(173).total)
        assertEquals(BigDecimal("1420.00"),calc.calcular(180).total)
        assertNull(calc.calcular(180).tarifaSiguiente)
    }
    @Test fun periodo15y16() {
        assertEquals(LocalDate.of(2026,8,16),PeriodoFacturacionCalculator.obtenerPeriodo(LocalDate.of(2026,9,15)).first)
        assertEquals(LocalDate.of(2026,9,16),PeriodoFacturacionCalculator.obtenerPeriodo(LocalDate.of(2026,9,16)).first)
    }
    @Test fun cambioIgualRechazado() {
        assertThrows(IllegalArgumentException::class.java) { ServicioValidator.validar(TipoServicio.CAMBIO,null,6,6) }
    }
}
