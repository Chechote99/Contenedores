package com.contenedores.app.data.dao

import androidx.room3.*
import com.contenedores.app.data.entity.*
import java.time.LocalDate
import java.time.LocalDateTime

@Dao interface JornadaDao {
    @Query("SELECT * FROM jornadas WHERE estado = 'ABIERTA' LIMIT 1") suspend fun obtenerJornadaAbierta(): JornadaEntity?
    @Query("SELECT * FROM jornadas WHERE id = :id LIMIT 1") suspend fun obtenerPorId(id: String): JornadaEntity?
    @Query("SELECT * FROM jornadas WHERE fecha = :fecha LIMIT 1") suspend fun obtenerPorFecha(fecha: LocalDate): JornadaEntity?
    @Query("SELECT * FROM jornadas WHERE fecha BETWEEN :desde AND :hasta ORDER BY fecha ASC") suspend fun obtenerEntreFechas(desde: LocalDate, hasta: LocalDate): List<JornadaEntity>
    @Query("SELECT * FROM jornadas ORDER BY fecha") suspend fun obtenerTodas(): List<JornadaEntity>
    @Query("DELETE FROM jornadas") suspend fun eliminarTodos()
    @Insert suspend fun insertarTodos(items: List<JornadaEntity>)
    @Insert suspend fun insertar(item: JornadaEntity)
    @Update suspend fun actualizar(item: JornadaEntity)
}

@Dao interface ViajeDao {
    @Query("SELECT * FROM viajes WHERE id = :id LIMIT 1") suspend fun obtenerPorId(id: String): ViajeEntity?
    @Query("SELECT * FROM viajes WHERE jornadaId = :jornadaId AND estado = 'EN_CURSO' LIMIT 1") suspend fun obtenerViajeEnCurso(jornadaId: String): ViajeEntity?
    @Query("SELECT COALESCE(MAX(numero),0) FROM viajes WHERE jornadaId = :jornadaId") suspend fun obtenerUltimoNumero(jornadaId: String): Int
    @Query("SELECT * FROM viajes WHERE jornadaId = :jornadaId ORDER BY numero") suspend fun obtenerDeJornada(jornadaId: String): List<ViajeEntity>
    @Query("SELECT * FROM viajes ORDER BY inicio") suspend fun obtenerTodos(): List<ViajeEntity>
    @Query("DELETE FROM viajes") suspend fun eliminarTodos()
    @Insert suspend fun insertarTodos(items: List<ViajeEntity>)
    @Insert suspend fun insertar(item: ViajeEntity)
    @Update suspend fun actualizar(item: ViajeEntity)
}

@Dao interface ServicioDao {
    @Query("SELECT * FROM servicios WHERE id = :id LIMIT 1") suspend fun obtenerPorId(id: String): ServicioEntity?
    @Query("SELECT * FROM servicios WHERE viajeId = :viajeId ORDER BY inicio") suspend fun obtenerDeViaje(viajeId: String): List<ServicioEntity>
    @Query("SELECT * FROM servicios WHERE jornadaId = :jornadaId ORDER BY inicio") suspend fun obtenerDeJornada(jornadaId: String): List<ServicioEntity>
    @Query("SELECT * FROM servicios WHERE periodoFacturacionId = :periodoId AND estado = 'FINALIZADO' ORDER BY numeroFacturacion") suspend fun obtenerDelPeriodo(periodoId: String): List<ServicioEntity>
    @Query("SELECT * FROM servicios WHERE estado = 'FINALIZADO' AND fin >= :desde AND fin < :hasta ORDER BY fin") suspend fun obtenerFinalizadosEntre(desde: LocalDateTime, hasta: LocalDateTime): List<ServicioEntity>
    @Query("SELECT COUNT(*) FROM servicios WHERE periodoFacturacionId = :periodoId AND estado = 'FINALIZADO'") suspend fun contarFinalizadosPeriodo(periodoId: String): Int
    @Query("SELECT COALESCE(MAX(numeroFacturacion),0) FROM servicios WHERE periodoFacturacionId = :periodoId AND estado = 'FINALIZADO'") suspend fun obtenerUltimoNumeroFacturacion(periodoId: String): Int
    @Query("SELECT * FROM servicios WHERE estado = 'EN_CURSO' LIMIT 1") suspend fun obtenerEnCurso(): ServicioEntity?
    @Query("SELECT * FROM servicios WHERE jornadaId = :jornadaId AND estado = 'EN_CURSO' LIMIT 1") suspend fun obtenerServicioEnCursoDeJornada(jornadaId: String): ServicioEntity?
    @Query("SELECT * FROM servicios ORDER BY inicio") suspend fun obtenerTodos(): List<ServicioEntity>
    @Query("DELETE FROM servicios") suspend fun eliminarTodos()
    @Insert suspend fun insertarTodos(items: List<ServicioEntity>)
    @Insert suspend fun insertar(item: ServicioEntity)
    @Update suspend fun actualizar(item: ServicioEntity)
    @Delete suspend fun eliminar(item: ServicioEntity)
}

@Dao interface PeriodoFacturacionDao {
    @Query("SELECT * FROM periodos_facturacion WHERE id = :id LIMIT 1") suspend fun obtenerPorId(id: String): PeriodoFacturacionEntity?
    @Query("SELECT * FROM periodos_facturacion WHERE fechaInicio = :fechaInicio LIMIT 1") suspend fun obtenerPorInicio(fechaInicio: LocalDate): PeriodoFacturacionEntity?
    @Query("SELECT * FROM periodos_facturacion WHERE :fecha BETWEEN fechaInicio AND fechaFin LIMIT 1") suspend fun obtenerPorFecha(fecha: LocalDate): PeriodoFacturacionEntity?
    @Query("SELECT * FROM periodos_facturacion ORDER BY fechaInicio DESC") suspend fun obtenerTodos(): List<PeriodoFacturacionEntity>
    @Query("DELETE FROM periodos_facturacion") suspend fun eliminarTodos()
    @Insert suspend fun insertarTodos(items: List<PeriodoFacturacionEntity>)
    @Insert suspend fun insertar(item: PeriodoFacturacionEntity)
    @Update suspend fun actualizar(item: PeriodoFacturacionEntity)
}

@Dao interface TramoTarifaDao {
    @Query("SELECT * FROM tramos_tarifa WHERE activo = 1 ORDER BY desdeServicio") suspend fun obtenerActivos(): List<TramoTarifaEntity>
    @Query("SELECT * FROM tramos_tarifa ORDER BY desdeServicio") suspend fun obtenerTodos(): List<TramoTarifaEntity>
    @Query("SELECT COUNT(*) FROM tramos_tarifa") suspend fun contar(): Int
    @Query("DELETE FROM tramos_tarifa") suspend fun eliminarTodos()
    @Insert suspend fun insertarTodos(items: List<TramoTarifaEntity>)
    @Insert suspend fun insertar(item: TramoTarifaEntity)
    @Update suspend fun actualizar(item: TramoTarifaEntity)
    @Delete suspend fun eliminar(item: TramoTarifaEntity)
}

@Dao interface LugarDao {
    @Query("SELECT * FROM lugares ORDER BY categoria, nombre") suspend fun obtenerTodos(): List<LugarEntity>
    @Query("SELECT * FROM lugares WHERE id = :id LIMIT 1") suspend fun obtenerPorId(id: String): LugarEntity?
    @Query("DELETE FROM lugares") suspend fun eliminarTodos()
    @Insert suspend fun insertarTodos(items: List<LugarEntity>)
    @Insert suspend fun insertar(item: LugarEntity)
    @Update suspend fun actualizar(item: LugarEntity)
    @Delete suspend fun eliminar(item: LugarEntity)
}

@Dao interface VehiculoDao {
    @Query("SELECT * FROM vehiculos ORDER BY rowid LIMIT 1") suspend fun obtenerPrincipal(): VehiculoEntity?
    @Query("SELECT * FROM vehiculos ORDER BY matricula") suspend fun obtenerTodos(): List<VehiculoEntity>
    @Query("DELETE FROM vehiculos") suspend fun eliminarTodos()
    @Insert suspend fun insertarTodos(items: List<VehiculoEntity>)
    @Insert suspend fun insertar(item: VehiculoEntity)
    @Update suspend fun actualizar(item: VehiculoEntity)
}
