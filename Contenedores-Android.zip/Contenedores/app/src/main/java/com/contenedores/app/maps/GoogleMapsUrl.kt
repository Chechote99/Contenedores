package com.contenedores.app.maps

import android.net.Uri

object GoogleMapsUrl {
    fun crear(origen: String?, destino: String?): Uri? {
        if (origen.isNullOrBlank() || destino.isNullOrBlank()) return null
        return Uri.parse("https://www.google.com/maps/dir/?api=1&origin=${Uri.encode(origen)}&destination=${Uri.encode(destino)}")
    }
}
