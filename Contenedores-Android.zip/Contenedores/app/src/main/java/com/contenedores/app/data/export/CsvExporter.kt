package com.contenedores.app.data.export

import android.content.Context
import android.net.Uri
import com.contenedores.app.data.db.AppDatabase
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class CsvExporter(private val db: AppDatabase) {
    suspend fun exportar(context: Context, uri: Uri) {
        context.contentResolver.openOutputStream(uri)?.use { output ->
            ZipOutputStream(output).use { zip ->
                val j = db.jornadaDao().obtenerTodas()
                val v = db.viajeDao().obtenerTodos()
                val s = db.servicioDao().obtenerTodos()
                val p = db.periodoFacturacionDao().obtenerTodos()
                val t = db.tramoTarifaDao().obtenerTodos()
                val l = db.lugarDao().obtenerTodos()
                val c = db.vehiculoDao().obtenerTodos()
                add(zip,"jornadas.csv", listOf(listOf("id","fecha","inicio","fin","descanso_minutos","odometro_inicial","odometro_final","estado")) + j.map{listOf(it.id,it.fecha.toString(),it.inicio.toString(),it.fin?.toString() ?:  "",it.descansoMinutos.toString(),it.odometroInicial.toString(),it.odometroFinal?.toString() ?:  "",it.estado.name)})
                add(zip,"viajes.csv", listOf(listOf("id","jornada_id","numero","inicio","fin","origen","destino","km_viaje","estado")) + v.map{listOf(it.id,it.jornadaId,it.numero.toString(),it.inicio.toString(),it.fin?.toString() ?:  "",it.origenTexto?:"",it.destinoTexto?:"",it.kmViaje?.toString() ?:  "",it.estado.name)})
                add(zip,"servicios.csv", listOf(listOf("id","periodo_facturacion_id","jornada_id","viaje_id","numero_facturacion","inicio","fin","tipo","capacidad","capacidad_retirada","capacidad_puesta","direccion","tarifa","importe","estado")) + s.map{listOf(it.id,it.periodoFacturacionId,it.jornadaId,it.viajeId,it.numeroFacturacion?.toString() ?:  "",it.inicio.toString(),it.fin?.toString() ?:  "",it.tipo.name,it.capacidad?.toString() ?:  "",it.capacidadRetirada?.toString() ?:  "",it.capacidadPuesta?.toString() ?:  "",it.direccion?:"",it.tarifaAplicada?.toPlainString() ?:  "",it.importe?.toPlainString() ?:  "",it.estado.name)})
                add(zip,"periodos_facturacion.csv", listOf(listOf("id","fecha_inicio","fecha_fin","estado")) + p.map{listOf(it.id,it.fechaInicio.toString(),it.fechaFin.toString(),it.estado.name)})
                add(zip,"tramos_tarifa.csv", listOf(listOf("id","desde_servicio","hasta_servicio","importe_por_servicio","activo")) + t.map{listOf(it.id,it.desdeServicio.toString(),it.hastaServicio.toString(),it.importePorServicio.toPlainString(),it.activo.toString())})
                add(zip,"lugares.csv", listOf(listOf("id","nombre","direccion","latitud","longitud","place_id","categoria")) + l.map{listOf(it.id,it.nombre,it.direccion,it.latitud?.toString() ?:  "",it.longitud?.toString() ?:  "",it.placeId?:"",it.categoria.name)})
                add(zip,"vehiculos.csv", listOf(listOf("id","matricula","marca","modelo","odometro_actual")) + c.map{listOf(it.id,it.matricula,it.marca?:"",it.modelo?:"",it.odometroActual.toString())})
            }
        } ?: error("No se pudo crear el archivo.")
    }
    private fun add(zip:ZipOutputStream,name:String,rows:List<List<String>>){zip.putNextEntry(ZipEntry(name)); rows.forEach{row->zip.write(row.joinToString(","){csv(it)}.toByteArray());zip.write('\n'.code)};zip.closeEntry()}
    private fun csv(s:String)=if(s.contains(',')||s.contains('"')||s.contains('\n')) "\"${s.replace("\"","\"\"")}\"" else s
}
