package com.contenedores.app.domain.jornada

import androidx.room3.withWriteTransaction
import com.contenedores.app.data.db.AppDatabase
import com.contenedores.app.data.entity.*
import com.contenedores.app.domain.billing.*
import com.contenedores.app.domain.servicio.ServicioValidator
import java.math.BigDecimal
import java.time.Duration
import java.time.LocalDateTime

class AbrirJornadaUseCase(private val db: AppDatabase) {
    suspend operator fun invoke(odometroInicial: Int, ahora: LocalDateTime): JornadaEntity = db.withWriteTransaction {
        require(odometroInicial >= 0) { "El odómetro no puede ser negativo." }
        val dao = db.jornadaDao()
        check(dao.obtenerJornadaAbierta() == null) { "Ya existe una jornada abierta." }
        check(dao.obtenerPorFecha(ahora.toLocalDate()) == null) { "Ya existe una jornada para hoy." }
        JornadaEntity(fecha = ahora.toLocalDate(), inicio = ahora, odometroInicial = odometroInicial).also(dao::insertar)
    }
}

class IniciarViajeUseCase(private val db: AppDatabase) {
    suspend operator fun invoke(jornadaId: String, ahora: LocalDateTime): ViajeEntity = db.withWriteTransaction {
        val jornada = db.jornadaDao().obtenerPorId(jornadaId) ?: error("Jornada no encontrada.")
        check(jornada.estado == JornadaEstado.ABIERTA) { "La jornada está cerrada." }
        check(db.viajeDao().obtenerViajeEnCurso(jornadaId) == null) { "Ya existe un viaje en curso." }
        val numero = db.viajeDao().obtenerUltimoNumero(jornadaId) + 1
        ViajeEntity(jornadaId = jornadaId, numero = numero, inicio = ahora).also(db.viajeDao()::insertar)
    }
}

class CrearServicioUseCase(private val db: AppDatabase) {
    suspend operator fun invoke(
        jornadaId: String, viajeId: String, tipo: TipoServicio, capacidad: Int?, capacidadRetirada: Int?, capacidadPuesta: Int?,
        lugarId: String?, direccion: String?, latitud: Double?, longitud: Double?, placeId: String?, ahora: LocalDateTime
    ): ServicioEntity = db.withWriteTransaction {
        ServicioValidator.validar(tipo, capacidad, capacidadRetirada, capacidadPuesta)
        val jornada = db.jornadaDao().obtenerPorId(jornadaId) ?: error("Jornada no encontrada.")
        check(jornada.estado == JornadaEstado.ABIERTA)
        val viaje = db.viajeDao().obtenerPorId(viajeId) ?: error("Viaje no encontrado.")
        check(viaje.estado == ViajeEstado.EN_CURSO) { "El viaje no está en curso." }
        check(db.servicioDao().obtenerEnCurso() == null) { "Ya existe un servicio en curso." }
        val periodo = obtenerPeriodoFacturacionSeguro(db.periodoFacturacionDao(), ahora.toLocalDate())
        ServicioEntity(periodoFacturacionId = periodo.id, jornadaId = jornadaId, viajeId = viajeId, inicio = ahora, tipo = tipo,
            capacidad = capacidad, capacidadRetirada = capacidadRetirada, capacidadPuesta = capacidadPuesta,
            lugarId = lugarId, direccion = direccion, latitud = latitud, longitud = longitud, placeId = placeId)
            .also(db.servicioDao()::insertar)
    }
}

class FinalizarServicioUseCase(private val db: AppDatabase) {
    suspend operator fun invoke(servicioId: String, ahora: LocalDateTime): ServicioEntity = db.withWriteTransaction {
        val dao = db.servicioDao()
        val servicio = dao.obtenerPorId(servicioId) ?: error("Servicio no encontrado.")
        check(servicio.estado == ServicioEstado.EN_CURSO) { "El servicio ya está finalizado." }
        require(!ahora.isBefore(servicio.inicio)) { "La hora final no puede ser anterior al inicio." }
        val numero = dao.obtenerUltimoNumeroFacturacion(servicio.periodoFacturacionId) + 1
        val tarifa = TarifaCalculator(db.tramoTarifaDao().obtenerActivos()).obtenerTarifa(numero)
        val final = servicio.copy(numeroFacturacion = numero, fin = ahora, tarifaAplicada = tarifa, importe = tarifa, estado = ServicioEstado.FINALIZADO)
        dao.actualizar(final)
        final
    }
}

class CancelarServicioUseCase(private val db: AppDatabase) {
    suspend operator fun invoke(servicioId: String) = db.withWriteTransaction {
        val servicio = db.servicioDao().obtenerPorId(servicioId) ?: error("Servicio no encontrado.")
        check(servicio.estado == ServicioEstado.EN_CURSO)
        db.servicioDao().eliminar(servicio)
    }
}

class FinalizarViajeUseCase(private val db: AppDatabase) {
    suspend operator fun invoke(viajeId: String, ahora: LocalDateTime, kmViaje: Double?): ViajeEntity = db.withWriteTransaction {
        val viaje = db.viajeDao().obtenerPorId(viajeId) ?: error("Viaje no encontrado.")
        check(viaje.estado == ViajeEstado.EN_CURSO) { "El viaje ya está finalizado." }
        check(db.servicioDao().obtenerDeViaje(viajeId).none { it.estado == ServicioEstado.EN_CURSO }) { "No puedes finalizar el viaje mientras haya un servicio en curso." }
        require(!ahora.isBefore(viaje.inicio))
        require(kmViaje == null || kmViaje >= 0.0)
        viaje.copy(fin = ahora, kmViaje = kmViaje, estado = ViajeEstado.FINALIZADO).also(db.viajeDao()::actualizar)
    }
}

class FinalizarJornadaUseCase(private val db: AppDatabase) {
    suspend operator fun invoke(jornadaId: String, ahora: LocalDateTime, odometroFinal: Int, descansoMinutos: Int): JornadaEntity = db.withWriteTransaction {
        val jornada = db.jornadaDao().obtenerPorId(jornadaId) ?: error("Jornada no encontrada.")
        check(jornada.estado == JornadaEstado.ABIERTA) { "La jornada ya está cerrada." }
        check(db.servicioDao().obtenerServicioEnCursoDeJornada(jornadaId) == null) { "No puedes cerrar la jornada con un servicio en curso." }
        check(db.viajeDao().obtenerViajeEnCurso(jornadaId) == null) { "No puedes cerrar la jornada con un viaje en curso." }
        require(!ahora.isBefore(jornada.inicio))
        require(odometroFinal >= jornada.odometroInicial) { "El odómetro final no puede ser inferior al inicial." }
        val elapsed = Duration.between(jornada.inicio, ahora).toMinutes()
        require(descansoMinutos in 0..elapsed.toInt()) { "El descanso no es válido." }
        val final = jornada.copy(fin = ahora, odometroFinal = odometroFinal, descansoMinutos = descansoMinutos, estado = JornadaEstado.CERRADA)
        db.jornadaDao().actualizar(final)
        db.vehiculoDao().obtenerPrincipal()?.let { db.vehiculoDao().actualizar(it.copy(odometroActual = odometroFinal)) }
        final
    }
}
