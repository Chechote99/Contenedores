package com.contenedores.app.domain.estadisticas

import com.contenedores.app.data.entity.*
import com.contenedores.app.data.repository.*
import java.math.BigDecimal
import java.time.*
import java.time.temporal.TemporalAdjusters

sealed interface FiltroEstadisticas {
    data object Hoy : FiltroEstadisticas
    data object Semana : FiltroEstadisticas
    data object Mes : FiltroEstadisticas
    data object PeriodoFacturacion : FiltroEstadisticas
    data object Anio : FiltroEstadisticas
    data class Personalizado(val desde: LocalDate, val hasta: LocalDate) : FiltroEstadisticas
}
data class RangoFechas(val desde: LocalDate, val hasta: LocalDate)
object RangoFechasCalculator {
    fun calcular(filtro: FiltroEstadisticas, hoy: LocalDate = LocalDate.now()) = when (filtro) {
        FiltroEstadisticas.Hoy -> RangoFechas(hoy, hoy)
        FiltroEstadisticas.Semana -> { val d = hoy.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)); RangoFechas(d, d.plusDays(6)) }
        FiltroEstadisticas.Mes -> RangoFechas(hoy.withDayOfMonth(1), hoy.with(TemporalAdjusters.lastDayOfMonth()))
        FiltroEstadisticas.PeriodoFacturacion -> { val (d,f) = com.contenedores.app.domain.billing.PeriodoFacturacionCalculator.obtenerPeriodo(hoy); RangoFechas(d,f) }
        FiltroEstadisticas.Anio -> RangoFechas(hoy.withDayOfYear(1), hoy.with(TemporalAdjusters.lastDayOfYear()))
        is FiltroEstadisticas.Personalizado -> RangoFechas(filtro.desde, filtro.hasta)
    }
}
data class EstadisticasPeriodo(
    val desde: LocalDate, val hasta: LocalDate, val jornadas: Int, val viajes: Int, val servicios: Int,
    val kmReales: Int, val kmViajes: Double, val diferenciaKm: Double, val minutosTrabajados: Long,
    val puestas: Int, val retiradas: Int, val cambios: Int,
    val servicios3m3: Int, val servicios6m3: Int, val servicios9m3: Int,
    val facturacion: BigDecimal, val cambios3a6: Int, val cambios3a9: Int, val cambios6a3: Int,
    val cambios6a9: Int, val cambios9a6: Int, val cambios9a3: Int,
    val retiradas3m3: Int, val retiradas6m3: Int, val retiradas9m3: Int,
    val colocadas3m3: Int, val colocadas6m3: Int, val colocadas9m3: Int
)

class ObtenerEstadisticasUseCase(private val jornadas: JornadaRepository, private val viajes: ViajeRepository, private val servicios: ServicioRepository) {
    suspend operator fun invoke(filtro: FiltroEstadisticas): EstadisticasPeriodo {
        val r = RangoFechasCalculator.calcular(filtro)
        val js = jornadas.obtenerEntreFechas(r.desde, r.hasta)
        val ss = servicios.obtenerFinalizadosEntre(r.desde.atStartOfDay(), r.hasta.plusDays(1).atStartOfDay())
        val vs = js.flatMap { viajes.obtenerDeJornada(it.id) }
        fun cap(v: ServicioEntity, n: Int) = when (v.tipo) { TipoServicio.CAMBIO -> false; else -> v.capacidad == n }
        fun ch(a: Int,b: Int) = ss.count { it.tipo == TipoServicio.CAMBIO && it.capacidadRetirada == a && it.capacidadPuesta == b }
        val reales = js.sumOf { it.odometroFinal?.minus(it.odometroInicial) ?: 0 }
        val kms = vs.sumOf { it.kmViaje ?: 0.0 }
        val minutos = js.sumOf { j -> j.fin?.let { Duration.between(j.inicio,it).toMinutes() - j.descansoMinutos } ?: 0L }
        return EstadisticasPeriodo(r.desde,r.hasta,js.size,vs.count { it.estado == ViajeEstado.FINALIZADO },ss.size,reales,kms,reales-kms,minutos,
            ss.count { it.tipo==TipoServicio.PUESTA },ss.count { it.tipo==TipoServicio.RETIRADA },ss.count { it.tipo==TipoServicio.CAMBIO },
            ss.count { cap(it,3) },ss.count { cap(it,6) },ss.count { cap(it,9) },ss.sumOf { it.importe ?: BigDecimal.ZERO },
            ch(3,6),ch(3,9),ch(6,3),ch(6,9),ch(9,6),ch(9,3),
            ss.count { it.capacidadRetirada==3 },ss.count { it.capacidadRetirada==6 },ss.count { it.capacidadRetirada==9 },
            ss.count { it.capacidadPuesta==3 },ss.count { it.capacidadPuesta==6 },ss.count { it.capacidadPuesta==9 })
    }
}
