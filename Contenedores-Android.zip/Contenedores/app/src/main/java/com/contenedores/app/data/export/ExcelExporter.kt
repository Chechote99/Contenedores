package com.contenedores.app.data.export

import android.content.Context
import android.net.Uri
import com.contenedores.app.data.db.AppDatabase
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ExcelExporter(private val db: AppDatabase) {
    suspend fun exportar(context: Context, uri: Uri) {
        val jornadas = db.jornadaDao().obtenerTodas()
        val viajes = db.viajeDao().obtenerTodos()
        val servicios = db.servicioDao().obtenerTodos()
        val periodos = db.periodoFacturacionDao().obtenerTodos()
        val tarifas = db.tramoTarifaDao().obtenerTodos()
        val lugares = db.lugarDao().obtenerTodos()
        val vehiculos = db.vehiculoDao().obtenerTodos()
        context.contentResolver.openOutputStream(uri)?.use { out ->
            ZipOutputStream(out).use { zip ->
                put(zip,"[Content_Types].xml",contentTypes())
                put(zip,"_rels/.rels",rels())
                put(zip,"xl/workbook.xml",workbook(listOf("Jornadas","Viajes","Servicios","Facturacion","Tarifas","Lugares","Vehiculos")))
                put(zip,"xl/_rels/workbook.xml.rels",workbookRels(7))
                val sheets = listOf(
                    "Jornadas" to jornadas.map{listOf(it.id,it.fecha.toString(),it.inicio.toString(),it.fin?.toString() ?:  "",it.odometroInicial.toString(),it.odometroFinal?.toString() ?:  "",it.estado.name)},
                    "Viajes" to viajes.map{listOf(it.id,it.jornadaId,it.numero.toString(),it.inicio.toString(),it.fin?.toString() ?:  "",it.origenTexto?:"",it.destinoTexto?:"",it.kmViaje?.toString() ?:  "",it.estado.name)},
                    "Servicios" to servicios.map{listOf(it.id,it.periodoFacturacionId,it.jornadaId,it.viajeId,it.numeroFacturacion?.toString() ?:  "",it.inicio.toString(),it.fin?.toString() ?:  "",it.tipo.name,it.capacidad?.toString() ?:  "",it.capacidadRetirada?.toString() ?:  "",it.capacidadPuesta?.toString() ?:  "",it.direccion?:"",it.tarifaAplicada?.toPlainString() ?:  "",it.importe?.toPlainString() ?:  "",it.estado.name)},
                    "Facturacion" to periodos.map{listOf(it.id,it.fechaInicio.toString(),it.fechaFin.toString(),it.estado.name)},
                    "Tarifas" to tarifas.map{listOf(it.id,it.desdeServicio.toString(),it.hastaServicio.toString(),it.importePorServicio.toPlainString(),it.activo.toString())},
                    "Lugares" to lugares.map{listOf(it.id,it.nombre,it.direccion,it.categoria.name,it.latitud?.toString() ?:  "",it.longitud?.toString() ?:  "",it.placeId?:"")},
                    "Vehiculos" to vehiculos.map{listOf(it.id,it.matricula,it.marca?:"",it.modelo?:"",it.odometroActual.toString())}
                )
                sheets.forEachIndexed { i,(_,rows) -> put(zip,"xl/worksheets/sheet${i+1}.xml",sheet(rows)) }
            }
        } ?: error("No se pudo crear el archivo.")
    }
    private fun put(z:ZipOutputStream,name:String,text:String){z.putNextEntry(ZipEntry(name));z.write(text.toByteArray(Charsets.UTF_8));z.closeEntry()}
    private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
    private fun sheet(rows:List<List<String>>):String { val all=listOf(emptyList<String>())+rows; return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>"+rows.mapIndexed{r,row->"<row r=\"${r+1}\">"+row.mapIndexed{c,v->"<c r=\"${col(c)}${r+1}\" t=\"inlineStr\"><is><t>${esc(v)}</t></is></c>"}.joinToString("")+"</row>"}.joinToString("")+"</sheetData></worksheet>" }
    private fun col(i:Int):String { var n=i+1;var s="";while(n>0){val r=(n-1)%26;s=Char('A'.code+r)+s;n=(n-1)/26};return s }
    private fun contentTypes()="<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>${(1..7).joinToString(""){ "<Override PartName=\"/xl/worksheets/sheet$it.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"}}</Types>"
    private fun rels()="<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"
    private fun workbook(names:List<String>)="<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>${names.mapIndexed{i,n->"<sheet name=\"$n\" sheetId=\"${i+1}\" r:id=\"rId${i+1}\"/>"}.joinToString("")}</sheets></workbook>"
    private fun workbookRels(n:Int)="<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">${(1..n).joinToString(""){ "<Relationship Id=\"rId$it\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet$it.xml\"/>"}}</Relationships>"
}
