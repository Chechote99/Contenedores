package com.contenedores.app.domain.billing

import com.contenedores.app.data.dao.PeriodoFacturacionDao
import com.contenedores.app.data.entity.*
import java.math.BigDecimal
import java.time.LocalDate

object PeriodoFacturacionCalculator {
    fun obtenerPeriodo(fecha: LocalDate): Pair<LocalDate, LocalDate> = if (fecha.dayOfMonth >= 16) {
        fecha.withDayOfMonth(16) to fecha.plusMonths(1).withDayOfMonth(15)
    } else {
        fecha.minusMonths(1).withDayOfMonth(16) to fecha.withDayOfMonth(15)
    }
}

class TarifaNoConfiguradaException(val numeroServicio: Int) : IllegalStateException("No existe tarifa configurada para el servicio $numeroServicio")

class TarifaCalculator(private val tramos: List<TramoTarifaEntity>) {
    fun obtenerTarifa(numeroServicio: Int): BigDecimal = tramos.firstOrNull { it.activo && numeroServicio in it.desdeServicio..it.hastaServicio }?.importePorServicio
        ?: throw TarifaNoConfiguradaException(numeroServicio)
}

data class DesgloseTarifa(val desde: Int, val hasta: Int, val serviciosAplicados: Int, val precioUnitario: BigDecimal, val subtotal: BigDecimal)
data class ResumenInterno(val total: BigDecimal, val siguienteServicio: Int, val tarifaSiguiente: BigDecimal?, val desglose: List<DesgloseTarifa>, val siguienteTramoHasta: Int?)

class FacturacionCalculator(private val tramos: List<TramoTarifaEntity>) {
    fun calcular(numeroServicios: Int): ResumenInterno {
        require(numeroServicios >= 0)
        var total = BigDecimal.ZERO
        val desglose = mutableListOf<DesgloseTarifa>()
        val ordenados = tramos.filter { it.activo }.sortedBy { it.desdeServicio }
        for (tramo in ordenados) {
            if (numeroServicios < tramo.desdeServicio) break
            val ultimo = minOf(numeroServicios, tramo.hastaServicio)
            val cantidad = ultimo - tramo.desdeServicio + 1
            if (cantidad > 0) {
                val subtotal = tramo.importePorServicio.multiply(BigDecimal.valueOf(cantidad.toLong()))
                total = total.add(subtotal)
                desglose += DesgloseTarifa(tramo.desdeServicio, tramo.hastaServicio, cantidad, tramo.importePorServicio, subtotal)
            }
        }
        val siguiente = numeroServicios + 1
        val siguienteTramo = ordenados.firstOrNull { siguiente in it.desdeServicio..it.hastaServicio }
        return ResumenInterno(total, siguiente, siguienteTramo?.importePorServicio, desglose, siguienteTramo?.hastaServicio)
    }
}

suspend fun obtenerPeriodoFacturacionSeguro(dao: PeriodoFacturacionDao, fecha: LocalDate): PeriodoFacturacionEntity {
    dao.obtenerPorFecha(fecha)?.let { return it }
    val (inicio, fin) = PeriodoFacturacionCalculator.obtenerPeriodo(fecha)
    dao.obtenerPorInicio(inicio)?.let { return it }
    return try {
        PeriodoFacturacionEntity(fechaInicio = inicio, fechaFin = fin).also { dao.insertar(it) }
    } catch (e: Exception) {
        dao.obtenerPorInicio(inicio) ?: throw e
    }
}
