package com.contenedores.app.domain.servicio

import com.contenedores.app.data.entity.TipoServicio

object ServicioValidator {
    private val capacidadesValidas = setOf(3, 6, 9)
    fun validar(tipo: TipoServicio, capacidad: Int?, capacidadRetirada: Int?, capacidadPuesta: Int?) {
        when (tipo) {
            TipoServicio.PUESTA, TipoServicio.RETIRADA -> {
                require(capacidad in capacidadesValidas) { "Selecciona una capacidad." }
                require(capacidadRetirada == null && capacidadPuesta == null)
            }
            TipoServicio.CAMBIO -> {
                require(capacidad == null)
                require(capacidadRetirada in capacidadesValidas) { "Selecciona la capacidad retirada." }
                require(capacidadPuesta in capacidadesValidas) { "Selecciona la capacidad colocada." }
                require(capacidadRetirada != capacidadPuesta) { "Las capacidades del cambio deben ser diferentes." }
            }
        }
    }
}
