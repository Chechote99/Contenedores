package com.contenedores.app

import android.app.Application
import com.google.android.libraries.places.api.Places
import com.contenedores.app.data.db.DatabaseProvider

class ContenedoresApplication : Application() {
    lateinit var database: com.contenedores.app.data.db.AppDatabase
        private set
    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.PLACES_API_KEY.isNotBlank() && !Places.isInitialized()) {
            Places.initializeWithNewPlacesApiEnabled(applicationContext, BuildConfig.PLACES_API_KEY)
        }
        database = DatabaseProvider.get(this)
    }
}
