package com.contenedores.app.data.entity

import androidx.room3.Entity
import androidx.room3.Index
import androidx.room3.PrimaryKey
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.UUID

enum class JornadaEstado { ABIERTA, CERRADA }
enum class ViajeEstado { EN_CURSO, FINALIZADO }
enum class TipoServicio { PUESTA, RETIRADA, CAMBIO }
enum class ServicioEstado { EN_CURSO, FINALIZADO }
enum class PeriodoEstado { ACTIVO, CERRADO }
enum class CategoriaLugar { BASE, PLANTA, OBRA, OTRO }

@Entity(tableName = "jornadas", indices = [Index(value = ["fecha"], unique = true)])
data class JornadaEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val fecha: LocalDate,
    val inicio: LocalDateTime,
    val fin: LocalDateTime? = null,
    val descansoMinutos: Int = 0,
    val odometroInicial: Int,
    val odometroFinal: Int? = null,
    val observaciones: String? = null,
    val estado: JornadaEstado = JornadaEstado.ABIERTA
)

@Entity(tableName = "viajes", indices = [Index(value = ["jornadaId"]), Index(value = ["jornadaId", "numero"], unique = true)])
data class ViajeEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val jornadaId: String,
    val numero: Int,
    val inicio: LocalDateTime,
    val fin: LocalDateTime? = null,
    val origenTexto: String? = null,
    val origenLatitud: Double? = null,
    val origenLongitud: Double? = null,
    val destinoTexto: String? = null,
    val destinoLatitud: Double? = null,
    val destinoLongitud: Double? = null,
    val kmViaje: Double? = null,
    val observaciones: String? = null,
    val estado: ViajeEstado = ViajeEstado.EN_CURSO
)

@Entity(tableName = "servicios", indices = [
    Index(value = ["periodoFacturacionId", "numeroFacturacion"], unique = true),
    Index(value = ["jornadaId"]), Index(value = ["viajeId"]), Index(value = ["periodoFacturacionId"])
])
data class ServicioEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val periodoFacturacionId: String,
    val jornadaId: String,
    val viajeId: String,
    val numeroFacturacion: Int? = null,
    val inicio: LocalDateTime,
    val fin: LocalDateTime? = null,
    val tipo: TipoServicio,
    val capacidad: Int? = null,
    val capacidadRetirada: Int? = null,
    val capacidadPuesta: Int? = null,
    val lugarId: String? = null,
    val direccion: String? = null,
    val latitud: Double? = null,
    val longitud: Double? = null,
    val placeId: String? = null,
    val tarifaAplicada: BigDecimal? = null,
    val importe: BigDecimal? = null,
    val kmViaje: Double? = null,
    val observaciones: String? = null,
    val estado: ServicioEstado = ServicioEstado.EN_CURSO
)

@Entity(tableName = "periodos_facturacion", indices = [Index(value = ["fechaInicio"], unique = true)])
data class PeriodoFacturacionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val fechaInicio: LocalDate,
    val fechaFin: LocalDate,
    val estado: PeriodoEstado = PeriodoEstado.ACTIVO
)

@Entity(tableName = "tramos_tarifa", indices = [Index(value = ["desdeServicio"], unique = true)])
data class TramoTarifaEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val desdeServicio: Int,
    val hastaServicio: Int,
    val importePorServicio: BigDecimal,
    val activo: Boolean = true
)

@Entity(tableName = "lugares")
data class LugarEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val nombre: String,
    val direccion: String,
    val latitud: Double? = null,
    val longitud: Double? = null,
    val placeId: String? = null,
    val categoria: CategoriaLugar
)

@Entity(tableName = "vehiculos")
data class VehiculoEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val matricula: String,
    val marca: String? = null,
    val modelo: String? = null,
    val odometroActual: Int,
    val alturaMetros: Double? = null,
    val anchuraMetros: Double? = null,
    val longitudMetros: Double? = null,
    val pesoToneladas: Double? = null
)
