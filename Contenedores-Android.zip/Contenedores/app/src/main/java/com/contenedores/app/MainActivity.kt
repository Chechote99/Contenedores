package com.contenedores.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.contenedores.app.data.entity.*
import com.contenedores.app.domain.billing.*
import com.contenedores.app.domain.estadisticas.*
import com.contenedores.app.domain.jornada.*
import com.contenedores.app.maps.GoogleMapsUrl
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.time.*
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as ContenedoresApplication
        setContent { ContenedoresTheme { ContenedoresApp(app.database) } }
    }
}

@Composable
fun ContenedoresTheme(content: @Composable () -> Unit) {
    MaterialTheme(content = content)
}

enum class Tab { HOY, CALENDARIO, ESTADISTICAS, FACTURACION, AJUSTES }

@Composable
fun ContenedoresApp(db: com.contenedores.app.data.db.AppDatabase) {
    var tab by remember { mutableStateOf(Tab.HOY) }
    var refresh by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar {
            Tab.entries.forEach { t -> NavigationBarItem(selected = tab==t, onClick={tab=t}, icon={}, label={Text(t.name.lowercase().replaceFirstChar{it.uppercase()})}) }
        }
    }) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when(tab) {
                Tab.HOY -> HoyScreen(db) { refresh++ }
                Tab.CALENDARIO -> CalendarioScreen(db)
                Tab.ESTADISTICAS -> EstadisticasScreen(db)
                Tab.FACTURACION -> FacturacionScreen(db)
                Tab.AJUSTES -> AjustesScreen(db)
            }
        }
    }
}

@Composable
fun HoyScreen(db: com.contenedores.app.data.db.AppDatabase, onChanged: () -> Unit) {
    var jornada by remember { mutableStateOf<JornadaEntity?>(null) }
    var viaje by remember { mutableStateOf<ViajeEntity?>(null) }
    var servicio by remember { mutableStateOf<ServicioEntity?>(null) }
    var odometro by remember { mutableStateOf("") }
    var showStart by remember { mutableStateOf(false) }
    var showTrip by remember { mutableStateOf(false) }
    var showService by remember { mutableStateOf(false) }
    var showFinishService by remember { mutableStateOf(false) }
    var showFinishTrip by remember { mutableStateOf(false) }
    var showFinishDay by remember { mutableStateOf(false) }
    var tipo by remember { mutableStateOf(TipoServicio.PUESTA) }
    var cap by remember { mutableIntStateOf(6) }
    var capR by remember { mutableIntStateOf(6) }
    var capP by remember { mutableIntStateOf(9) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    fun load() { scope.launch { jornada=db.jornadaDao().obtenerJornadaAbierta(); viaje=jornada?.let{db.viajeDao().obtenerViajeEnCurso(it.id)}; servicio=viaje?.let{db.servicioDao().obtenerDeViaje(it.id).lastOrNull{ s->s.estado==ServicioEstado.EN_CURSO }} } }
    LaunchedEffect(Unit) { load() }
    val servicesToday by produceState(0, jornada) { value = jornada?.let { db.servicioDao().obtenerDeJornada(it.id).count { s -> s.estado==ServicioEstado.FINALIZADO } } ?: 0 }
    val km = jornada?.odometroFinal?.minus(jornada!!.odometroInicial)
    val billing by produceState<ResumenInterno?>(null, jornada, servicesToday) { value = jornada?.let { p -> val period=db.periodoFacturacionDao().obtenerPorFecha(p.fecha) ?: obtenerPeriodoFacturacionSeguro(db.periodoFacturacionDao(),p.fecha); FacturacionCalculator(db.tramoTarifaDao().obtenerActivos()).calcular(db.servicioDao().contarFinalizadosPeriodo(period.id)) } }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("HOY · ${LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM"))}", style=MaterialTheme.typography.headlineMedium) }
        item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text(if(jornada==null) "SIN JORNADA" else "JORNADA EN CURSO", style=MaterialTheme.typography.titleLarge)
                if(jornada==null) Button(onClick={showStart=true}, modifier=Modifier.fillMaxWidth().height(56.dp)){Text("+ INICIAR JORNADA")}
                else {
                    Text("Inicio ${jornada!!.inicio.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))}")
                    Text("Odómetro ${jornada!!.odometroInicial} km")
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { AssistChip(onClick={}, label={Text("$servicesToday servicios")}); AssistChip(onClick={}, label={Text("${km ?: "—"} km reales")}) }
                }
            }}
        }
        if(jornada!=null) item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                if(viaje==null) Button(onClick={showTrip=true}, modifier=Modifier.fillMaxWidth().height(56.dp)){Text("+ INICIAR VIAJE")}
                else { Text("VIAJE ${viaje!!.numero}", style=MaterialTheme.typography.titleLarge); Text("${viaje!!.inicio.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))} → EN CURSO"); Text(if(servicio==null) "Sin servicio en curso" else "Servicio en curso") }
                if(viaje!=null && servicio==null) Button(onClick={showService=true}, modifier=Modifier.fillMaxWidth().height(56.dp)){Text("+ AÑADIR SERVICIO")}
                if(servicio!=null) Button(onClick={showFinishService=true}, modifier=Modifier.fillMaxWidth().height(56.dp)){Text("FINALIZAR SERVICIO")}
                if(viaje!=null && servicio==null) OutlinedButton(onClick={showFinishTrip=true}, modifier=Modifier.fillMaxWidth().height(56.dp)){Text("FINALIZAR VIAJE")}
                if(viaje==null) OutlinedButton(onClick={showFinishDay=true}, modifier=Modifier.fillMaxWidth().height(56.dp)){Text("FINALIZAR JORNADA")}
            }}
        }
        item { Text("FACTURACIÓN DEL PERIODO", style=MaterialTheme.typography.titleMedium); Text("${billing?.siguienteServicio ?: "—"} · ${billing?.tarifaSiguiente?.let{money(it)} ?: "Tarifa no configurada"}") }
        if(error!=null) item { Text(error!!, color=MaterialTheme.colorScheme.error) }
    }

    if(showStart) SimpleDialog("INICIAR JORNADA", "Odómetro inicial", odometro, {odometro=it}, "INICIAR") { scope.launch { try { AbrirJornadaUseCase(db)(odometro.toInt(),LocalDateTime.now()); showStart=false; odometro=""; load(); onChanged() } catch(e:Exception){error=e.message} } } 
    if(showTrip) ConfirmDialog("INICIAR VIAJE", "Se iniciará el viaje actual.", "INICIAR") { scope.launch { try { IniciarViajeUseCase(db)(jornada!!.id,LocalDateTime.now()); showTrip=false; load(); onChanged() } catch(e:Exception){error=e.message} } }
    if(showService) ServiceDialog(tipo, {tipo=it}, cap, {cap=it}, capR, {capR=it}, capP, {capP=it}, { scope.launch { try { CrearServicioUseCase(db)(jornada!!.id,viaje!!.id,tipo,if(tipo==TipoServicio.CAMBIO)null else cap,if(tipo==TipoServicio.CAMBIO)capR else null,if(tipo==TipoServicio.CAMBIO)capP else null,null,null,null,null,null,LocalDateTime.now()); showService=false; load(); onChanged() } catch(e:Exception){error=e.message} } }, {showService=false})
    if(showFinishService) ConfirmDialog("FINALIZAR SERVICIO", "Se asignará el siguiente número y tarifa del periodo.", "FINALIZAR") { scope.launch { try { FinalizarServicioUseCase(db)(servicio!!.id,LocalDateTime.now()); showFinishService=false; load(); onChanged() } catch(e:Exception){error=e.message} } }
    if(showFinishTrip) SimpleDialog("FINALIZAR VIAJE", "Km del viaje (opcional)", "", {odometro=it}, "FINALIZAR") { scope.launch { try { FinalizarViajeUseCase(db)(viaje!!.id,LocalDateTime.now(),odometro.toDoubleOrNull()); showFinishTrip=false; odometro=""; load(); onChanged() } catch(e:Exception){error=e.message} } }
    if(showFinishDay) SimpleDialog("FINALIZAR JORNADA", "Odómetro final", "", {odometro=it}, "FINALIZAR") { scope.launch { try { FinalizarJornadaUseCase(db)(jornada!!.id,LocalDateTime.now(),odometro.toInt(),0); showFinishDay=false; odometro=""; load(); onChanged() } catch(e:Exception){error=e.message} } }
}

fun money(v: BigDecimal) = "${v.setScale(2)} €"

@Composable fun SimpleDialog(title:String,label:String,value:String,onValue:(String)->Unit,confirm:String,onConfirm:()->Unit){ AlertDialog(onDismissRequest={}, title={Text(title)}, text={OutlinedTextField(value,onValue,label={Text(label)})}, confirmButton={Button(onClick=onConfirm){Text(confirm)}}, dismissButton={TextButton(onClick={}){Text("CANCELAR")}}) }
@Composable fun ConfirmDialog(title:String,text:String,confirm:String,onConfirm:()->Unit){ AlertDialog(onDismissRequest={}, title={Text(title)}, text={Text(text)}, confirmButton={Button(onClick=onConfirm){Text(confirm)}}, dismissButton={TextButton(onClick={}){Text("CANCELAR")}}) }
@Composable fun ServiceDialog(tipo:TipoServicio,onTipo:(TipoServicio)->Unit,cap:Int,onCap:(Int)->Unit,capR:Int,onCapR:(Int)->Unit,capP:Int,onCapP:(Int)->Unit,onSave:()->Unit,onCancel:()->Unit){ AlertDialog(onDismissRequest=onCancel,title={Text("AÑADIR SERVICIO")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){ TipoServicio.entries.forEach{FilterChip(selected=tipo==it,onClick={onTipo(it)},label={Text(it.name)})}; if(tipo!=TipoServicio.CAMBIO){Text("CAPACIDAD"); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf(3,6,9).forEach{FilterChip(selected=cap==it,onClick={onCap(it)},label={Text("$it m³")})}}}else{Text("RETIRADA");Row{listOf(3,6,9).forEach{FilterChip(selected=capR==it,onClick={onCapR(it)},label={Text("$it")})}};Text("PUESTA");Row{listOf(3,6,9).forEach{FilterChip(selected=capP==it,onClick={onCapP(it)},label={Text("$it")})}}}},confirmButton={Button(onClick=onSave){Text("INICIAR")}},dismissButton={TextButton(onClick=onCancel){Text("CANCELAR")}})}

@Composable fun CalendarioScreen(db: com.contenedores.app.data.db.AppDatabase){ var month by remember{mutableStateOf(YearMonth.now())}; var selected by remember{mutableStateOf<LocalDate?>(null)}; val days=remember(month){(0 until 42).map{month.atDay(1).minusDays((month.atDay(1).dayOfWeek.value-1).toLong()).plusDays(it.toLong())}}; val jornadas by produceState(emptyList<JornadaEntity>(),month){value=db.jornadaDao().obtenerEntreFechas(days.first(),days.last())}; val counts by produceState(emptyMap<String,Int>(),jornadas){val all=jornadas.flatMap{db.servicioDao().obtenerDeJornada(it.id)}; value=all.filter{it.estado==ServicioEstado.FINALIZADO}.groupingBy{it.jornadaId}.eachCount()}; LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("CALENDARIO",style=MaterialTheme.typography.headlineMedium);Row{TextButton(onClick={month=month.minusMonths(1)}){Text("<")};Text(month.toString());TextButton(onClick={month=month.plusMonths(1)}){Text(">")}}}};item{LazyVerticalGrid(columns=GridCells.Fixed(7),modifier=Modifier.height(360.dp)){items(days){d->Card(onClick={selected=d},modifier=Modifier.padding(2.dp)){Column(Modifier.padding(6.dp)){Text(d.dayOfMonth.toString());Text((counts[jornadas.firstOrNull{it.fecha==d}?.id]?:0).toString())}}}}};if(selected!=null){item{val j=jornadas.firstOrNull{it.fecha==selected};if(j==null)Text("${selected}: No hay jornada registrada.") else Card{Column(Modifier.padding(16.dp)){Text(selected.toString(),style=MaterialTheme.typography.titleLarge);Text("${j.odometroFinal?.minus(j.odometroInicial) ?: "—"} km reales");Text("${counts[j.id]?:0} servicios")}}}}}}

@Composable fun EstadisticasScreen(db: com.contenedores.app.data.db.AppDatabase){ var filtro by remember{mutableStateOf<FiltroEstadisticas>(FiltroEstadisticas.Hoy)}; var data by remember{mutableStateOf<EstadisticasPeriodo?>(null)}; LaunchedEffect(filtro){data=ObtenerEstadisticasUseCase(com.contenedores.app.data.repository.JornadaRepository(db.jornadaDao()),com.contenedores.app.data.repository.ViajeRepository(db.viajeDao()),com.contenedores.app.data.repository.ServicioRepository(db.servicioDao()))(filtro)}; LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("ESTADÍSTICAS",style=MaterialTheme.typography.headlineMedium)};item{Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(FiltroEstadisticas.Hoy,FiltroEstadisticas.Semana,FiltroEstadisticas.Mes,FiltroEstadisticas.PeriodoFacturacion,FiltroEstadisticas.Anio).forEach{FilterChip(selected=filtro==it,onClick={filtro=it},label={Text(when(it){FiltroEstadisticas.Hoy->"Hoy";FiltroEstadisticas.Semana->"Semana";FiltroEstadisticas.Mes->"Mes";FiltroEstadisticas.PeriodoFacturacion->"16→15";else->"Año"})})}}};data?.let{d->item{StatCard("SERVICIOS","${d.servicios}")};item{StatCard("FACTURACIÓN",money(d.facturacion))};item{StatCard("KM REALES","${d.kmReales} km")};item{StatCard("KM DE VIAJES","${"%.1f".format(d.kmViajes)} km")};item{StatCard("DIFERENCIA","${"%.1f".format(d.diferenciaKm)} km")};item{StatCard("JORNADAS","${d.jornadas}")};item{StatCard("VIAJES","${d.viajes}")};item{StatCard("PUESTAS / RETIRADAS / CAMBIOS","${d.puestas} / ${d.retiradas} / ${d.cambios}")}}}}
@Composable fun StatCard(title:String,value:String){Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(title);Text(value,style=MaterialTheme.typography.titleLarge)}}}

@Composable fun FacturacionScreen(db: com.contenedores.app.data.db.AppDatabase){ var periods by remember{mutableStateOf<List<PeriodoFacturacionEntity>>(emptyList())}; var selected by remember{mutableStateOf<PeriodoFacturacionEntity?>(null)}; LaunchedEffect(Unit){periods=db.periodoFacturacionDao().obtenerTodos(); if(periods.isEmpty()){obtenerPeriodoFacturacionSeguro(db.periodoFacturacionDao(),LocalDate.now());periods=db.periodoFacturacionDao().obtenerTodos()};selected=periods.firstOrNull()}; val resumen by produceState<ResumenInterno?>(null,selected){value=selected?.let{FacturacionCalculator(db.tramoTarifaDao().obtenerActivos()).calcular(db.servicioDao().obtenerUltimoNumeroFacturacion(it.id))}}; LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("FACTURACIÓN",style=MaterialTheme.typography.headlineMedium)};item{periods.forEach{p->TextButton(onClick={selected=p}){Text("${p.fechaInicio} → ${p.fechaFin}")}}};resumen?.let{r->item{StatCard("SERVICIOS","${r.siguienteServicio-1}")};item{StatCard("TOTAL",money(r.total))};item{StatCard("PRÓXIMO SERVICIO","${r.siguienteServicio}")};item{StatCard("TARIFA",r.tarifaSiguiente?.let(::money) ?: "No configurada")};r.desglose.forEach{d->item{Text("${d.serviciosAplicados} × ${money(d.precioUnitario)} = ${money(d.subtotal)}")}}}}}

@Composable fun AjustesScreen(db: com.contenedores.app.data.db.AppDatabase){ val scope=rememberCoroutineScope(); var tariffs by remember{mutableStateOf<List<TramoTarifaEntity>>(emptyList())}; LaunchedEffect(Unit){if(db.tramoTarifaDao().contar()==0) InicializarDatosUseCase(db.tramoTarifaDao())();tariffs=db.tramoTarifaDao().obtenerTodos()}; LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("AJUSTES",style=MaterialTheme.typography.headlineMedium)};item{Text("FACTURACIÓN",style=MaterialTheme.typography.titleLarge)};tariffs.forEach{t->item{Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),Modifier.fillMaxWidth(),Arrangement.SpaceBetween){Text("${t.desdeServicio} → ${t.hastaServicio}");Text(money(t.importePorServicio))}}}};item{Text("MIS LUGARES",style=MaterialTheme.typography.titleLarge)};item{Text("Gestiona bases, plantas y obras desde aquí.")};item{Text("VEHÍCULO",style=MaterialTheme.typography.titleLarge)};item{Text("Odómetro y perfil de rutas.")};item{Text("DATOS",style=MaterialTheme.typography.titleLarge)};item{Text("Exportación CSV/Excel y copia completa JSON estarán disponibles mediante Storage Access Framework.")}}}
