package com.contenedores.app.data.db

import android.content.Context
import androidx.room3.Database
import androidx.room3.Room
import androidx.room3.RoomDatabase
import androidx.room3.TypeConverter
import androidx.room3.TypeConverters
import androidx.sqlite.driver.bundled.BundledSQLiteDriver
import com.contenedores.app.data.dao.*
import com.contenedores.app.data.entity.*
import kotlinx.coroutines.Dispatchers
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalDateTime

class AppTypeConverters {
    @TypeConverter fun date(v: LocalDate?) = v?.toString()
    @TypeConverter fun date(v: String?) = v?.let(LocalDate::parse)
    @TypeConverter fun dateTime(v: LocalDateTime?) = v?.toString()
    @TypeConverter fun dateTime(v: String?) = v?.let(LocalDateTime::parse)
    @TypeConverter fun decimal(v: BigDecimal?) = v?.toPlainString()
    @TypeConverter fun decimal(v: String?) = v?.let(::BigDecimal)
    @TypeConverter fun jornada(v: JornadaEstado?) = v?.name
    @TypeConverter fun jornada(v: String?) = v?.let(JornadaEstado::valueOf)
    @TypeConverter fun viaje(v: ViajeEstado?) = v?.name
    @TypeConverter fun viaje(v: String?) = v?.let(ViajeEstado::valueOf)
    @TypeConverter fun servicio(v: ServicioEstado?) = v?.name
    @TypeConverter fun servicio(v: String?) = v?.let(ServicioEstado::valueOf)
    @TypeConverter fun tipo(v: TipoServicio?) = v?.name
    @TypeConverter fun tipo(v: String?) = v?.let(TipoServicio::valueOf)
    @TypeConverter fun periodo(v: PeriodoEstado?) = v?.name
    @TypeConverter fun periodo(v: String?) = v?.let(PeriodoEstado::valueOf)
    @TypeConverter fun categoria(v: CategoriaLugar?) = v?.name
    @TypeConverter fun categoria(v: String?) = v?.let(CategoriaLugar::valueOf)
}

@Database(entities = [JornadaEntity::class, ViajeEntity::class, ServicioEntity::class, LugarEntity::class, PeriodoFacturacionEntity::class, TramoTarifaEntity::class, VehiculoEntity::class], version = 1, exportSchema = true)
@TypeConverters(AppTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun jornadaDao(): JornadaDao
    abstract fun viajeDao(): ViajeDao
    abstract fun servicioDao(): ServicioDao
    abstract fun periodoFacturacionDao(): PeriodoFacturacionDao
    abstract fun tramoTarifaDao(): TramoTarifaDao
    abstract fun lugarDao(): LugarDao
    abstract fun vehiculoDao(): VehiculoDao
}

object DatabaseProvider {
    @Volatile private var instance: AppDatabase? = null
    fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
        instance ?: Room.databaseBuilder<AppDatabase>(context.applicationContext, "contenedores.db")
            .setDriver(BundledSQLiteDriver())
            .setQueryCoroutineContext(Dispatchers.IO)
            .build().also { instance = it }
    }
}
