package com.contenedores.app.data.repository

import com.contenedores.app.data.dao.*
import com.contenedores.app.data.entity.*
import java.time.LocalDate
import java.time.LocalDateTime

class JornadaRepository(private val dao: JornadaDao) {
    suspend fun obtenerAbierta() = dao.obtenerJornadaAbierta()
    suspend fun obtenerPorId(id: String) = dao.obtenerPorId(id)
    suspend fun obtenerPorFecha(fecha: LocalDate) = dao.obtenerPorFecha(fecha)
    suspend fun obtenerEntreFechas(desde: LocalDate, hasta: LocalDate) = dao.obtenerEntreFechas(desde, hasta)
    suspend fun obtenerTodas() = dao.obtenerTodas()
}
class ViajeRepository(private val dao: ViajeDao) {
    suspend fun obtenerPorId(id: String) = dao.obtenerPorId(id)
    suspend fun obtenerEnCurso(jornadaId: String) = dao.obtenerViajeEnCurso(jornadaId)
    suspend fun obtenerDeJornada(jornadaId: String) = dao.obtenerDeJornada(jornadaId)
    suspend fun obtenerTodos() = dao.obtenerTodos()
}
class ServicioRepository(private val dao: ServicioDao) {
    suspend fun obtenerPorId(id: String) = dao.obtenerPorId(id)
    suspend fun obtenerDeViaje(id: String) = dao.obtenerDeViaje(id)
    suspend fun obtenerDeJornada(id: String) = dao.obtenerDeJornada(id)
    suspend fun obtenerFinalizadosEntre(desde: LocalDateTime, hasta: LocalDateTime) = dao.obtenerFinalizadosEntre(desde, hasta)
    suspend fun obtenerDelPeriodo(id: String) = dao.obtenerDelPeriodo(id)
    suspend fun obtenerEnCurso() = dao.obtenerEnCurso()
}
class LugarRepository(private val dao: LugarDao) {
    suspend fun obtenerTodos() = dao.obtenerTodos()
    suspend fun obtenerPorId(id: String) = dao.obtenerPorId(id)
    suspend fun insertar(item: LugarEntity) = dao.insertar(item)
    suspend fun actualizar(item: LugarEntity) = dao.actualizar(item)
    suspend fun eliminar(item: LugarEntity) = dao.eliminar(item)
}
class VehiculoRepository(private val dao: VehiculoDao) {
    suspend fun obtenerPrincipal() = dao.obtenerPrincipal()
    suspend fun obtenerTodos() = dao.obtenerTodos()
    suspend fun insertar(item: VehiculoEntity) = dao.insertar(item)
    suspend fun actualizar(item: VehiculoEntity) = dao.actualizar(item)
}
