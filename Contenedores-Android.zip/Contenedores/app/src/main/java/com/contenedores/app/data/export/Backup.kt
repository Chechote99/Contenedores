package com.contenedores.app.data.export

import android.content.Context
import android.net.Uri
import androidx.room3.withWriteTransaction
import com.contenedores.app.data.db.AppDatabase
import com.contenedores.app.data.entity.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.InputStream
import java.io.OutputStream
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalDateTime

@Serializable data class BackupDto(val version:Int=1,val creadoEn:String,val jornadas:List<JornadaBackupDto>,val viajes:List<ViajeBackupDto>,val servicios:List<ServicioBackupDto>,val periodos:List<PeriodoBackupDto>,val tarifas:List<TarifaBackupDto>,val lugares:List<LugarBackupDto>,val vehiculos:List<VehiculoBackupDto>)
@Serializable data class JornadaBackupDto(val id:String,val fecha:String,val inicio:String,val fin:String?,val descansoMinutos:Int,val odometroInicial:Int,val odometroFinal:Int?,val observaciones:String?,val estado:String)
@Serializable data class ViajeBackupDto(val id:String,val jornadaId:String,val numero:Int,val inicio:String,val fin:String?,val origenTexto:String?,val origenLatitud:Double?,val origenLongitud:Double?,val destinoTexto:String?,val destinoLatitud:Double?,val destinoLongitud:Double?,val kmViaje:Double?,val observaciones:String?,val estado:String)
@Serializable data class ServicioBackupDto(val id:String,val periodoFacturacionId:String,val jornadaId:String,val viajeId:String,val numeroFacturacion:Int?,val inicio:String,val fin:String?,val tipo:String,val capacidad:Int?,val capacidadRetirada:Int?,val capacidadPuesta:Int?,val lugarId:String?,val direccion:String?,val latitud:Double?,val longitud:Double?,val placeId:String?,val tarifaAplicada:String?,val importe:String?,val kmViaje:Double?,val observaciones:String?,val estado:String)
@Serializable data class PeriodoBackupDto(val id:String,val fechaInicio:String,val fechaFin:String,val estado:String)
@Serializable data class TarifaBackupDto(val id:String,val desdeServicio:Int,val hastaServicio:Int,val importePorServicio:String,val activo:Boolean)
@Serializable data class LugarBackupDto(val id:String,val nombre:String,val direccion:String,val latitud:Double?,val longitud:Double?,val placeId:String?,val categoria:String)
@Serializable data class VehiculoBackupDto(val id:String,val matricula:String,val marca:String?,val modelo:String?,val odometroActual:Int,val alturaMetros:Double?,val anchuraMetros:Double?,val longitudMetros:Double?,val pesoToneladas:Double?)

object BackupMapper {
    fun create(db: AppDatabase): BackupDto = error("Use BackupService.create() suspend")
    suspend fun createSuspend(db: AppDatabase): BackupDto = BackupDto(
        creadoEn=LocalDateTime.now().toString(),
        jornadas=db.jornadaDao().obtenerTodas().map{JornadaBackupDto(it.id,it.fecha.toString(),it.inicio.toString(),it.fin?.toString(),it.descansoMinutos,it.odometroInicial,it.odometroFinal,it.observaciones,it.estado.name)},
        viajes=db.viajeDao().obtenerTodos().map{ViajeBackupDto(it.id,it.jornadaId,it.numero,it.inicio.toString(),it.fin?.toString(),it.origenTexto,it.origenLatitud,it.origenLongitud,it.destinoTexto,it.destinoLatitud,it.destinoLongitud,it.kmViaje,it.observaciones,it.estado.name)},
        servicios=db.servicioDao().obtenerTodos().map{ServicioBackupDto(it.id,it.periodoFacturacionId,it.jornadaId,it.viajeId,it.numeroFacturacion,it.inicio.toString(),it.fin?.toString(),it.tipo.name,it.capacidad,it.capacidadRetirada,it.capacidadPuesta,it.lugarId,it.direccion,it.latitud,it.longitud,it.placeId,it.tarifaAplicada?.toPlainString(),it.importe?.toPlainString(),it.kmViaje,it.observaciones,it.estado.name)},
        periodos=db.periodoFacturacionDao().obtenerTodos().map{PeriodoBackupDto(it.id,it.fechaInicio.toString(),it.fechaFin.toString(),it.estado.name)},
        tarifas=db.tramoTarifaDao().obtenerTodos().map{TarifaBackupDto(it.id,it.desdeServicio,it.hastaServicio,it.importePorServicio.toPlainString(),it.activo)},
        lugares=db.lugarDao().obtenerTodos().map{LugarBackupDto(it.id,it.nombre,it.direccion,it.latitud,it.longitud,it.placeId,it.categoria.name)},
        vehiculos=db.vehiculoDao().obtenerTodos().map{VehiculoBackupDto(it.id,it.matricula,it.marca,it.modelo,it.odometroActual,it.alturaMetros,it.anchuraMetros,it.longitudMetros,it.pesoToneladas)}
    )
}

object BackupValidator {
    fun validar(b: BackupDto) {
        require(b.version == 1) { "Versión de copia no compatible: ${b.version}" }
        val jornadas=b.jornadas.map{it.id}.toSet(); val viajes=b.viajes.map{it.id}.toSet(); val periodos=b.periodos.map{it.id}.toSet(); val lugares=b.lugares.map{it.id}.toSet()
        require(jornadas.size==b.jornadas.size && viajes.size==b.viajes.size && periodos.size==b.periodos.size) { "La copia contiene IDs duplicados." }
        require(b.viajes.all{it.jornadaId in jornadas}) { "Hay viajes con jornada inexistente." }
        require(b.servicios.all{it.jornadaId in jornadas && it.viajeId in viajes && it.periodoFacturacionId in periodos && (it.lugarId==null || it.lugarId in lugares)}) { "Hay servicios con referencias rotas." }
        require(b.tarifas.all{it.desdeServicio>=1 && it.hastaServicio>=it.desdeServicio && BigDecimal(it.importePorServicio)>=BigDecimal.ZERO}) { "Hay tarifas inválidas." }
    }
}

class BackupService(private val db: AppDatabase) {
    private val json=Json { prettyPrint=true; ignoreUnknownKeys=false }
    suspend fun exportar(uri: Uri, context: Context) { val b=BackupMapper.createSuspend(db); context.contentResolver.openOutputStream(uri)?.use{it.write(json.encodeToString(BackupDto.serializer(),b).toByteArray(Charsets.UTF_8))} ?: error("No se pudo crear el archivo.") }
    suspend fun importar(uri: Uri, context: Context) { val text=context.contentResolver.openInputStream(uri)?.use{it.readBytes().toString(Charsets.UTF_8)} ?: error("No se pudo leer la copia."); val b=json.decodeFromString(BackupDto.serializer(),text); BackupValidator.validar(b); db.withWriteTransaction { db.servicioDao().eliminarTodos();db.viajeDao().eliminarTodos();db.jornadaDao().eliminarTodos();db.periodoFacturacionDao().eliminarTodos();db.tramoTarifaDao().eliminarTodos();db.lugarDao().eliminarTodos();db.vehiculoDao().eliminarTodos(); db.periodoFacturacionDao().insertarTodos(b.periodos.map{PeriodoFacturacionEntity(it.id,LocalDate.parse(it.fechaInicio),LocalDate.parse(it.fechaFin),PeriodoEstado.valueOf(it.estado))}); db.tramoTarifaDao().insertarTodos(b.tarifas.map{TramoTarifaEntity(it.id,it.desdeServicio,it.hastaServicio,BigDecimal(it.importePorServicio),it.activo)}); db.lugarDao().insertarTodos(b.lugares.map{LugarEntity(it.id,it.nombre,it.direccion,it.latitud,it.longitud,it.placeId,CategoriaLugar.valueOf(it.categoria))}); db.vehiculoDao().insertarTodos(b.vehiculos.map{VehiculoEntity(it.id,it.matricula,it.marca,it.modelo,it.odometroActual,it.alturaMetros,it.anchuraMetros,it.longitudMetros,it.pesoToneladas)}); db.jornadaDao().insertarTodos(b.jornadas.map{JornadaEntity(it.id,LocalDate.parse(it.fecha),LocalDateTime.parse(it.inicio),it.fin?.let(LocalDateTime::parse),it.descansoMinutos,it.odometroInicial,it.odometroFinal,it.observaciones,JornadaEstado.valueOf(it.estado))}); db.viajeDao().insertarTodos(b.viajes.map{ViajeEntity(it.id,it.jornadaId,it.numero,LocalDateTime.parse(it.inicio),it.fin?.let(LocalDateTime::parse),it.origenTexto,it.origenLatitud,it.origenLongitud,it.destinoTexto,it.destinoLatitud,it.destinoLongitud,it.kmViaje,it.observaciones,ViajeEstado.valueOf(it.estado))}); db.servicioDao().insertarTodos(b.servicios.map{ServicioEntity(it.id,it.periodoFacturacionId,it.jornadaId,it.viajeId,it.numeroFacturacion,LocalDateTime.parse(it.inicio),it.fin?.let(LocalDateTime::parse),TipoServicio.valueOf(it.tipo),it.capacidad,it.capacidadRetirada,it.capacidadPuesta,it.lugarId,it.direccion,it.latitud,it.longitud,it.placeId,it.tarifaAplicada?.let(::BigDecimal),it.importe?.let(::BigDecimal),it.kmViaje,it.observaciones,ServicioEstado.valueOf(it.estado))}) } }
}
